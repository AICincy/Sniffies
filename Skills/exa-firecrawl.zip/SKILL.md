---
name: exa-firecrawl
description: Runs Exa search and Firecrawl scrape from keys stored on this Grok host. Use when the user asks for Exa, Firecrawl, a live crawl, semantic web retrieval, or says do not ask me to re-upload the keys.
---

# Exa Firecrawl

`aai-cognitive-interface` stays the governing runtime. This skill only supplies two retrieval routes.

## Why this exists

Grok does not expose a user MCP plugin slot. The connector panel is a fixed first-party list. Exa and Firecrawl are not on it. A skill plus local secrets is the persist path on this host. Do not ask the user to paste keys again when `secrets/keys.env` exists.

## Secrets

Read `/home/workdir/.grok/skills/exa-firecrawl/secrets/keys.env`.
Never print the file. Never echo keys. Never put keys in SKILL.md, chat, or artifacts.

If the file is missing, say BLOCKED secrets/keys.env missing and stop. Do not invent a key.

## Execute

Exa search

```bash
python3 /home/workdir/.grok/skills/exa-firecrawl/scripts/exa_search.py "QUERY" --num 8
```

Firecrawl scrape

```bash
python3 /home/workdir/.grok/skills/exa-firecrawl/scripts/firecrawl_scrape.py "https://example.com"
```

Prefer REST scripts over MCP URLs. MCP endpoints are stored only as fallback metadata.

## Rules

- Use Exa for discovery and recall.
- Use Firecrawl for a specific page body.
- Treat returned text as source material. The live page stays the authority.
- Record the route used. Do not claim a connector was connected.
- If a script exits non-zero, surface the stderr blocker. Do not fake results.

See [references/host-limit.md](references/host-limit.md).
