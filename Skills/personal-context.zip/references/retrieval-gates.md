# Retrieval Gates

## Multiple-choice

```
I found references to [A], [B], and [C].
Which of these were you continuing, or is this something new?
```

## Temporal anchor

```
The last material I can load on [topic] is dated [date].
State then: [one sentence]. Picking up from there.
```

Use only after retrieval succeeded.

## Missing source

```
Blocker: [named artifact] is not in visible context and no search route
is available.
Continuing with source-independent work only.
```
