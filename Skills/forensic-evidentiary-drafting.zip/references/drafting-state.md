# Drafting State

AAI owns objective, authorized scope, constraints, takeover, and AAI status
labels. This record is domain state only.

```yaml
canonical_sources: list of identities
observations: typed source statements
propositions: analytical claims with source links
conflicts: unresolved or adverse items
authority_state: verified-this-session | stale-table | missing
audience: court | agency | internal
artifact_type: analysis | declaration | inventory | timeline | appendix
mechanical_validation: PASS | FAIL | NOT-RUN
readiness: DRAFT | PROVISIONAL | FINAL-DRAFT | FILED
filing_blocker: null | string
```

Rules:

- Narrative coherence cannot convert sequence into causation, allegation into finding, or dispute into fact.
- Missing or adverse evidence stays visible.
- `FILED` requires independent transmission evidence. This skill cannot award it.
- Mechanical script pass plus missing auditor is still `PROVISIONAL`.
- Filing, service, and clerk upload are AAI human-only gates.
