# Sixth Circuit First Amendment Recording Appendix

This appendix is a starting point for forensic analyses and suppression
memo appendices involving the right to record police activity in public,
Terry stop predicates, and related Section 1983 / Monell claims. It is
organized by verification status, not by which side it favors.

Every entry in this appendix is subject to the same rule as any other
citation in this skill: authority-currency-auditor runs before delivery,
regardless of the status shown here. The statuses below reflect the last
check recorded in the relevant matter file's citation status cache, not
a standing guarantee.

## Doctrinal framework

| Question | Governing framework |
|---|---|
| Was the stop lawful at inception? | Terry v. Ohio, 392 U.S. 1 (1968): reasonable suspicion of criminal activity based on specific, articulable facts |
| Is recording police in public protected activity? | First Amendment, as applied to the states via the Fourteenth Amendment. No Sixth Circuit published opinion squarely recognizes this right on a public sidewalk as of the last check in this matter's citation cache |
| Is the municipality liable apart from individual officers? | Monell v. Dept. of Social Services, 436 U.S. 658 (1978): municipal liability requires a policy, custom, or practice, not respondeat superior |
| Do individual officers have qualified immunity? | Pearson v. Callahan, 555 U.S. 223 (2009): two-prong test, constitutional violation and clearly established law at the time of the conduct |
| Federal criminal civil rights referral | 18 U.S.C. 241 / 242: DOJ declines the large majority of referrals; treat as a documentation step, not a primary remedy |

## Verified for this matter

| Citation | Holding relevant here | Status (per matter file cache) |
|---|---|---|
| Crawford v. Geiger, 996 F. Supp. 2d 603 (N.D. Ohio 2014) | Strongest in-circuit authority found to date on recording police in public. District court only, not binding precedent | Verify before each new filing; record result in the matter's citation status cache |

## Candidate persuasive authority (out-of-circuit, unverified)

These are commonly cited in right-to-record litigation outside the Sixth
Circuit. None has been checked by authority-currency-auditor for this
matter. Do not cite any of these in a filing until verified. If
verification fails or the case cannot be confirmed, remove it rather
than cite it.

| Citation (as commonly reported, unverified) | Circuit | Relevance |
|---|---|---|
| Glik v. Cunniffe, 655 F.3d 78 (1st Cir. 2011) | First | Right to record police performing duties in public |
| ACLU of Illinois v. Alvarez, 679 F.3d 583 (7th Cir. 2012) | Seventh | Eavesdropping statute as applied to recording police |
| Fields v. City of Philadelphia, 862 F.3d 353 (3d Cir. 2017) | Third | Right to record, qualified immunity for pre-ruling conduct |
| Turner v. Driver, 848 F.3d 678 (5th Cir. 2017) | Fifth | Right to record, clearly-established-law analysis |

## Matter-specific policy citations

These are department policy provisions, not case law. authority-currency-auditor
does not cover department policy currency; verify against the
current CPD policy manual directly.

| Provision | Relevance |
|---|---|
| CPD Procedure 14.215 | Recording police activity |
| CPD Procedure 12.545 | Use of force proportionality |
| CPD Procedure 12.554 | Articulable facts requirement for detention |

## Using this appendix

IF a forensic analysis or suppression memo appendix involves a Terry
stop predicated on recording police activity:
THEN check this appendix for relevant framework citations before
searching from scratch. Run authority-currency-auditor on every citation
pulled from here, including the "verified for this matter" table, before
delivery. Record the result in the matter file's citation status cache.

IF a new case is found during research that belongs in this appendix:
THEN add it to the candidate table as unverified. Do not move it to the
verified table until authority-currency-auditor confirms it.
