#!/usr/bin/env python3
"""
validate_document.py

Mechanical pre-delivery validation gate for forensic-evidentiary-drafting
and regulatory-complaint-drafting documents. Implements the machine-
checkable half of the validation checklist. The judgment items (finding
sufficiency, AI-source reliability, companion-document requirements)
remain the model's responsibility. This script supplements the checklist;
it does not replace any item.

Checks:
  1. Em/en dash presence (U+2014, U+2013). Formatting rule per
     aai-cognitive-interface.
  2. Mandatory section order (I. through IX.) per
     forensic-evidentiary-drafting. Skipped with --skip-section-order
     (recipient letters under regulatory-complaint-drafting use a
     different structure).
  3. Exhibit cross-reference: exhibit identifiers cited in the body
     appear in the exhibit list section, and exhibit-list entries are
     cited somewhere in the body. Best-effort text match.
  4. Personal identifier patterns under the current Ohio Rules of
     Superintendence privacy provisions (Sup.R. 11.09 and 11.13 as of
     the July 1, 2026 restructuring): SSN
     (NNN-NN-NNNN), full date of birth adjacent to a birth keyword,
     and 9-16 digit runs flagged for account-number review.
  5. Attestation position: the attestation heading is the last section
     heading in the document.
  6. Timestamp consistency: with --ground-truth FILE, every HH:MM:SS
     timestamp in the draft must link to the same ground-truth event through
     a matching Event-ID/Anchor-ID or exact normalized non-time event text.
     Clock equality alone is not event verification. For offset diagnosis run
     claim-source-auditor's diff_timestamps.py directly.

Conventions match correct_timestamps.py: report-only, one finding per line,
exit nonzero on any FAIL or unresolved REVIEW, no file mutation.

Usage:
    python3 validate_document.py DRAFT.md
    python3 validate_document.py DRAFT.md --ground-truth TRUTH.md
    python3 validate_document.py DRAFT.md --skip-section-order
"""

import argparse
import re
import sys

EMDASH = "\u2014"
ENDASH = "\u2013"
SECTION_ORDER = ["I.", "II.", "III.", "IV.", "V.", "VI.", "VII.", "VIII.", "IX."]
HHMMSS = re.compile(r"\b(\d{1,2}):(\d{2}):(\d{2})\b")
CONTEXT_TOKEN = re.compile(
    r"(?<![a-z0-9])[-+]?(?:[$\u00a3\u20ac]\s*)?"
    r"(?:\d+(?:,\d{3})*(?:\.\d+)?|\.\d+)%?"
    r"|[a-z]+(?:'[a-z]+)?",
    re.IGNORECASE,
)
ANCHOR = re.compile(
    r"\b(?:event-id|anchor-id)\s*[:=]\s*([a-z0-9._-]+)\b",
    re.IGNORECASE,
)
SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
DOB_CONTEXT = re.compile(
    r"(birth|born|d\.?o\.?b\.?)[^\n]{0,40}?\b(\d{1,2}[/-]\d{1,2}[/-]\d{4})\b",
    re.IGNORECASE,
)
LONG_DIGITS = re.compile(r"\b\d{9,16}\b")
EXHIBIT_REF = re.compile(
    r"\b(?:Exhibit|Ex\.)\s+([A-Z]{1,2}\d{0,3}|\d{1,3})\b",
    re.IGNORECASE,
)
EXHIBIT_LIST_HEADING = re.compile(
    r"^#{1,3}\s+(?:VII\.\s+)?Exhibit List\s*$",
    re.IGNORECASE | re.MULTILINE,
)
NUMBERED_EXHIBIT_LIST_HEADING = re.compile(
    r"^#{1,3}\s+VII\.\s+Exhibit List\s*$",
    re.IGNORECASE | re.MULTILINE,
)


def find_lines(text, pattern):
    hits = []
    for n, line in enumerate(text.splitlines(), 1):
        for m in pattern.finditer(line):
            hits.append((n, m.group(0)))
    return hits


def check_dashes(text, findings):
    for n, line in enumerate(text.splitlines(), 1):
        if EMDASH in line or ENDASH in line:
            findings.append(("FAIL", f"line {n}: em or en dash present"))


def check_section_order(text, findings):
    positions = []
    for label in SECTION_ORDER:
        pat = re.compile(r"^#{1,3}\s*" + re.escape(label), re.MULTILINE)
        m = pat.search(text)
        positions.append((label, m.start() if m else None))
    missing = [lbl for lbl, pos in positions if pos is None]
    if missing:
        findings.append(
            ("FAIL", f"sections missing or unheaded: {', '.join(missing)} "
             "(empty sections must state 'Not applicable to this document')")
        )
    present = [(lbl, pos) for lbl, pos in positions if pos is not None]
    ordered = sorted(present, key=lambda x: x[1])
    if [lbl for lbl, _ in present] != [lbl for lbl, _ in ordered]:
        findings.append(("FAIL", "section headings appear out of mandatory order"))


def check_exhibits(text, findings):
    heading = NUMBERED_EXHIBIT_LIST_HEADING.search(text) or EXHIBIT_LIST_HEADING.search(text)
    if heading is None:
        refs = set(m.group(1).upper() for m in EXHIBIT_REF.finditer(text))
        if refs:
            findings.append(("FAIL", "exhibits are cited but no exhibit list section was found"))
        return
    list_start = heading.start()
    body_before = text[:list_start]
    after_heading = heading.end()
    next_heading = re.search(r"^#{1,3}\s+", text[after_heading:], re.MULTILINE)
    list_end = after_heading + next_heading.start() if next_heading else len(text)
    listing = text[list_start:list_end]
    body = body_before + text[list_end:]
    body_refs = set(m.group(1).upper() for m in EXHIBIT_REF.finditer(body))
    list_refs = set()
    table_lines = [line for line in listing.splitlines() if line.lstrip().startswith("|")]
    exhibit_index = None
    data_rows = []
    if body_refs and not table_lines:
        findings.append(("FAIL", "exhibit list must be a formal table"))
    if table_lines:
        headers = [cell.strip().lower() for cell in table_lines[0].strip().strip("|").split("|")]
        exhibit_index = next((index for index, header in enumerate(headers)
                              if re.search(r"\b(?:exhibit|ex\.?|identifier|id)\b", header)), None)
        locator_index = next((index for index, header in enumerate(headers)
                              if re.search(r"\b(?:locator|timestamp|page|bates)\b", header)), None)
        device_file_index = next((index for index, header in enumerate(headers)
                                  if "source" in header and ("device" in header or "file" in header)), None)
        significance_index = next((index for index, header in enumerate(headers)
                                   if "significance" in header), None)
        missing_columns = [
            label for label, index in (
                ("exhibit identifier", exhibit_index),
                ("source locator", locator_index),
                ("source device/file", device_file_index),
                ("evidentiary significance", significance_index),
            ) if index is None
        ]
        required_indexes = [exhibit_index, locator_index, device_file_index, significance_index]
        if None not in required_indexes and len(set(required_indexes)) != 4:
            missing_columns.append("four distinct required columns")
        if missing_columns:
            findings.append(("FAIL", "exhibit table missing required column(s): " + ", ".join(missing_columns)))
        else:
            for line in table_lines[1:]:
                cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
                if cells and all(re.fullmatch(r":?-+:?", cell) for cell in cells):
                    continue
                data_rows.append(cells)
            if not data_rows:
                findings.append(("FAIL", "exhibit table has no data rows"))
            for row_number, cells in enumerate(data_rows, 1):
                missing_values = [
                    label for label, index in (
                        ("exhibit identifier", exhibit_index),
                        ("source locator", locator_index),
                        ("source device/file", device_file_index),
                        ("evidentiary significance", significance_index),
                    ) if index >= len(cells) or not cells[index]
                ]
                if missing_values:
                    findings.append(("FAIL", f"exhibit table row {row_number} missing value(s): "
                                     + ", ".join(missing_values)))
    for row_number, cells in enumerate(data_rows, 1):
        if exhibit_index is None or exhibit_index >= len(cells):
            continue
        identifier = cells[exhibit_index]
        if re.fullmatch(r"[A-Z]{1,2}\d{0,3}|\d{1,3}", identifier, re.IGNORECASE):
            normalized_identifier = identifier.upper()
            if normalized_identifier in list_refs:
                findings.append(("FAIL", f"duplicate exhibit identifier in row {row_number}: "
                                 f"{normalized_identifier}"))
            list_refs.add(normalized_identifier)
    orphan_cites = sorted(body_refs - list_refs)
    orphan_rows = sorted(list_refs - body_refs)
    if orphan_cites:
        findings.append(("FAIL", f"cited in body, absent from exhibit list: {', '.join(orphan_cites)}"))
    if orphan_rows:
        findings.append(("REVIEW", f"listed but never cited in body: {', '.join(orphan_rows)}"))


def check_identifiers(text, findings):
    for n, tok in find_lines(text, SSN):
        findings.append(("FAIL", f"line {n}: SSN pattern present ({tok}); redact under current Ohio filing-privacy rules"))
    for m in DOB_CONTEXT.finditer(text):
        findings.append(("FAIL", f"full date of birth near birth keyword: {m.group(2)}; use year only"))
    for n, tok in find_lines(text, LONG_DIGITS):
        if HHMMSS.search(tok):
            continue
        findings.append(("REVIEW", f"line {n}: {len(tok)}-digit run ({tok}); confirm not an account number"))


def check_attestation_position(text, findings):
    headings = [(m.start(), m.group(1).strip()) for m in
                re.finditer(r"^#{1,3}\s+(.+)$", text, re.MULTILINE)]
    if not headings:
        findings.append(("REVIEW", "no headings found; attestation position not checkable"))
        return
    att = [h for h in headings if "attestation" in h[1].lower()]
    if not att:
        findings.append(("FAIL", "no attestation heading found"))
        return
    if att[-1][0] != headings[-1][0]:
        findings.append(("FAIL", f"attestation is not the last section (last heading: '{headings[-1][1]}')"))


def anchors(line):
    return set(m.group(1).lower() for m in ANCHOR.finditer(line))


def normalize_spaced_signs(text):
    text = text.replace("\u2212", "-")
    number = r"(?:\d+(?:,\d{3})*(?:\.\d+)?|\.\d+)"
    accounting = rf"[$\u00a3\u20ac]?\s*{number}%?"
    text = re.sub(
        rf"\(\s*({accounting})\s*\)",
        lambda match: "-" + re.sub(r"\s+", "", match.group(1)),
        text,
    )
    numeric_start = r"(?:[$\u00a3\u20ac]\s*)?(?:\d|\.\d)"
    text = re.sub(
        rf"(?<=[a-z0-9)\]}}:=,])\s+([+\-])\s+(?={numeric_start})",
        r" \1",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(rf"(?<=[(\[{{])([+\-])\s+(?={numeric_start})", r"\1", text)
    text = re.sub(r"([+\-])\s*([$\u00a3\u20ac])\s*(?=(?:\d|\.\d))", r"\1\2", text)
    text = re.sub(r"([$\u00a3\u20ac])\s*([+\-])\s*(?=(?:\d|\.\d))", r"\2\1", text)
    trailing_amount = rf"(?:[$\u00a3\u20ac]\s*{number}|{number})%?"
    return re.sub(
        rf"(?<![a-z0-9])({trailing_amount})\s*([+\-])(?=\s|[.,;:)\]}}]|$)",
        lambda match: match.group(2) + re.sub(r"\s+", "", match.group(1)),
        text,
        flags=re.IGNORECASE,
    )


def normalized_context(line):
    without_times = HHMMSS.sub(" ", normalize_spaced_signs(line.lower()))
    without_anchors = ANCHOR.sub(" ", without_times)
    return " ".join(CONTEXT_TOKEN.findall(without_anchors))


def context_link(a, b):
    left_anchors, right_anchors = anchors(a), anchors(b)
    if left_anchors or right_anchors:
        return len(left_anchors) == 1 and left_anchors == right_anchors
    left, right = normalized_context(a), normalized_context(b)
    return bool(left and left == right)


def timestamp_seconds(match):
    hour, minute, second = (int(value) for value in match.groups())
    if not (0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59):
        return None
    return hour * 3600 + minute * 60 + second


def check_timestamps(text, truth_path, findings):
    try:
        truth = open(truth_path, encoding="utf-8").read()
    except (OSError, UnicodeError) as exc:
        raise RuntimeError(f"cannot read ground-truth file: {exc}") from exc
    truth_rows = []
    for truth_line_number, truth_line in enumerate(truth.splitlines(), 1):
        for match in HHMMSS.finditer(truth_line):
            if timestamp_seconds(match) is None:
                findings.append(("FAIL", f"ground-truth line {truth_line_number}: invalid timestamp {match.group(0)}"))
                continue
            truth_rows.append((truth_line_number, match.group(0), truth_line))
    for n, line in enumerate(text.splitlines(), 1):
        for m in HHMMSS.finditer(line):
            timestamp = m.group(0)
            if timestamp_seconds(m) is None:
                findings.append(("FAIL", f"line {n}: invalid timestamp {timestamp}"))
                continue
            candidates = [row for row in truth_rows if row[1] == timestamp]
            linked = [row for row in candidates if context_link(line, row[2])]
            if len(linked) == 1:
                continue
            if not candidates:
                findings.append(("FAIL", f"line {n}: timestamp {timestamp} not found in ground truth "
                                 "(run claim-source-auditor's diff_timestamps.py for offset diagnosis)"))
            elif not linked:
                findings.append(("REVIEW", f"line {n}: timestamp {timestamp} exists in ground truth "
                                 "but no stable event link establishes identity"))
            else:
                locators = ", ".join(str(row[0]) for row in linked)
                findings.append(("REVIEW", f"line {n}: timestamp {timestamp} links to multiple "
                                 f"ground-truth rows ({locators})"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("draft")
    ap.add_argument("--ground-truth", help="file of verified timestamps (matter file or overlay export)")
    ap.add_argument("--skip-section-order", action="store_true",
                    help="skip the nine-section order check (regulatory-complaint-drafting letters)")
    args = ap.parse_args()

    try:
        text = open(args.draft, encoding="utf-8").read()
    except (OSError, UnicodeError) as exc:
        print(f"ERROR: cannot read draft: {exc}", file=sys.stderr)
        sys.exit(2)
    findings = []

    check_dashes(text, findings)
    if not args.skip_section_order:
        check_section_order(text, findings)
    check_attestation_position(text, findings)
    check_exhibits(text, findings)
    check_identifiers(text, findings)
    if args.ground_truth:
        try:
            check_timestamps(text, args.ground_truth, findings)
        except RuntimeError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            sys.exit(2)

    fails = [f for f in findings if f[0] == "FAIL"]
    reviews = [f for f in findings if f[0] == "REVIEW"]
    for level, msg in findings:
        print(f"{level}: {msg}")
    if fails:
        status = "BLOCKED"
    elif reviews:
        status = "REVIEW-REQUIRED"
    else:
        status = "PASS"
    print(f"\nSummary: {len(fails)} blocking, {len(reviews)} review, {status}")
    sys.exit(1 if fails or reviews else 0)


if __name__ == "__main__":
    main()
