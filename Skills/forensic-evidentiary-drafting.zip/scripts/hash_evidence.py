#!/usr/bin/env python3
"""
hash_evidence.py

Computes SHA-256 hashes, sizes, and modification times for evidence
files, formatted as a markdown table ready to paste into the Exhibit
List or Evidence Inventory chain-of-custody table.

Usage:
    python3 hash_evidence.py FILE [FILE ...]
    python3 hash_evidence.py --dir DIRECTORY [--recursive]

Output columns match forensic-evidentiary-drafting's evidence inventory
chain-of-custody fields: source, format, hash, and a modified-time
column useful for establishing receipt order.

This script does not assign exhibit identifiers. Exhibit IDs come from
the matter file's exhibit ledger (see matter-file-template.md) to avoid
collisions across volumes.
"""

import argparse
import hashlib
import os
import stat
import sys
from datetime import datetime, timezone


def hash_record(path: str):
    h = hashlib.sha256()
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NONBLOCK", 0)
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, "rb") as f:
        before = os.fstat(f.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise OSError(f"not a regular evidence file: {path}")
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
        after = os.fstat(f.fileno())
    identity_before = (before.st_dev, before.st_ino)
    identity_after = (after.st_dev, after.st_ino)
    stable_fields_before = (before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    stable_fields_after = (after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    path_after = os.stat(path, follow_symlinks=False)
    if identity_before != identity_after or stable_fields_before != stable_fields_after:
        raise OSError(f"evidence changed while hashing: {path}")
    if identity_after != (path_after.st_dev, path_after.st_ino):
        raise OSError(f"evidence path was replaced while hashing: {path}")
    return h.hexdigest(), after


def collect_files(args) -> list[str]:
    files = []
    if args.dir:
        if args.recursive:
            for root, _dirs, names in os.walk(args.dir):
                for name in names:
                    files.append(os.path.join(root, name))
        else:
            for name in sorted(os.listdir(args.dir)):
                full = os.path.join(args.dir, name)
                if os.path.isfile(full):
                    files.append(full)
    files.extend(args.files)
    return sorted(set(os.path.abspath(f) for f in files))


def md_escape(value) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", nargs="*", help="Individual files to hash")
    parser.add_argument("--dir", help="Directory to scan")
    parser.add_argument(
        "--recursive", action="store_true", help="Recurse into subdirectories"
    )
    args = parser.parse_args()

    try:
        files = collect_files(args)
    except OSError as exc:
        print(f"ERROR: cannot enumerate requested evidence: {exc}", file=sys.stderr)
        sys.exit(2)
    if not files:
        print("No files found.", file=sys.stderr)
        sys.exit(1)

    print("| File | Format | SHA-256 | Size (bytes) | File mtime (UTC) |")
    print("|---|---|---|---|---|")
    errors = 0
    for path in files:
        try:
            digest, file_stat = hash_record(path)
        except OSError as exc:
            print(f"| {md_escape(path)} | error | {md_escape('error: ' + str(exc))} | | |")
            errors += 1
            continue
        size = file_stat.st_size
        mtime = datetime.fromtimestamp(file_stat.st_mtime, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        )
        ext = os.path.splitext(path)[1].lstrip(".").upper() or "unknown"
        print(f"| {md_escape(path)} | {md_escape(ext)} | `{digest}` | {size} | {mtime} |")
    if errors:
        print(f"\nERROR: {errors} requested evidence file(s) could not be hashed.", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
