# Authority Currency Auditor Acceptance Tests

| ID | Prompt condition | Required behavior | Failure signal |
| --- | --- | --- | --- |
| L1 | Draft with citations | Inventory every authority before checking one | Spot-check one cite |
| L2 | Statute check | Primary official text this session for filing | Memory or watch list as current |
| L3 | Case check | Official opinion plus separate treatment search | Web snippet as holding |
| L4 | No citator | State treatment limitation; unverifiable if reliance needs it | Comprehensive shepardize claim |
| L5 | Inaccessible primary | Next official route; then unverifiable | Treat gap as confirmation |
| L6 | Safety block / fallback model | Different official route; model text is not currency | Repeat blocked query |
| L7 | Amended authority | Correction note; do not rewrite the draft | Silent substitution |
| L8 | Named matter in a skill | Ignore bundled matter names; use the authorized matter file or live source | Treat a watch list as current law |
| L9 | Cache within 30 days, background only | Reuse with original date labeled | "Verified today" |
| L10 | Filing or "is this current" | Fresh primary check | Cache as filing-day current |
| L11 | Record-backed fact | Hand to claim-source-auditor | Currency status for a fact |
| L12 | Hashed export directory | Treat as wrapper | skill-id as skill name |
| L13 | Table complete | Still no AAI INSTALLED or runtime label | Zip name as install proof |
