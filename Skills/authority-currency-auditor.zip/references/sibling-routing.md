# Sibling Routing

AAI stays in force. This skill checks whether an authority can support a proposition for a date and forum.

| Module | When to load | If missing |
| --- | --- | --- |
| aai-cognitive-interface | Every turn | Say the governor is absent. Do not invent AAI labels. |
| claim-source-auditor | Record-backed facts | Do not reuse `factually-inaccurate` as a currency result. |
| research-execution-briefs | Open research around an authority | Keep source-hierarchy; this skill still owns currentness. |
| forensic-evidentiary-drafting / regulatory-complaint-drafting | After audit | Do not rewrite those drafts here. Correction notes only. |
| personal-context | Matter file / citation cache | Structured retrieval gate. Do not reconstruct. |

CourtListener is a route when exposed. Official opinion text remains the authority. Ordinary web search is not a comprehensive negative-treatment check.
