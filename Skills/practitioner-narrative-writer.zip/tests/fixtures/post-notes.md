# Fixture N1. Draft mode should fire.

Write a practitioner post from these notes.

Friction: the dashboard said ROAS was healthy after we raised spend, but incremental conversions flattened in week three.
Easy answer: keep scaling the winner.
Break: last $4,000 produced 11 conversions against a 28 conversion baseline on the prior $4,000.
Decision needed: stop treating blended ROAS as the scale signal.
Unproven: we do not yet have a holdout for that channel.
Voice sample: short sentences. Skeptical. No guru tone. No dialect other than the notes.
