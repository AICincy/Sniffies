#!/usr/bin/env python3
"""Static routing smoke for practitioner-narrative-writer."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures"

NEGATIVE = (
    "legal memorandum",
    "legal memo",
    "motion practice",
    "ohio civ.r",
    "forensic report",
    "evidence inventory",
    "regulatory complaint",
    "demand letter",
    "research-execution brief",
    "record-series",
    "handoff page",
)

POSITIVE = (
    "practitioner post",
    "notes-to-post",
    "write a practitioner post",
    "this reads ai",
    "continue the series",
    "explain the concept",
)


def classify(text: str) -> str:
    lowered = text.casefold()
    if any(token in lowered for token in NEGATIVE):
        return "DEFER"
    if any(token in lowered for token in POSITIVE):
        return "FIRE"
    return "UNKNOWN"


def main() -> int:
    cases = {
        "post-notes.md": "FIRE",
        "legal-memo.md": "DEFER",
    }
    results = []
    failed = 0
    for name, expected in cases.items():
        path = FIXTURES / name
        text = path.read_text(encoding="utf-8")
        got = classify(text)
        ok = got == expected
        if not ok:
            failed += 1
        results.append(
            {
                "fixture": name,
                "expected": expected,
                "got": got,
                "pass": ok,
            }
        )
    payload = {
        "mode": "routing-smoke",
        "status": "PASS" if failed == 0 else "FAIL",
        "failed": failed,
        "results": results,
        "note": "Static keyword routing only. Not RUNTIME-SMOKE-PASS.",
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
