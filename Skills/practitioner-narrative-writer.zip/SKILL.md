---
name: practitioner-narrative-writer
description: Writes or repairs practitioner social posts in draft, explain, continue, or review mode while keeping demonstrated voice and evidence bounds. Use when turning notes into a long-form post, explaining a technical concept conversationally, continuing a public series, or de-slopping a draft. Do not use for legal memos, forensic reports, regulatory complaints, research briefs, or record-series packets.
---

# Practitioner Narrative Writer

## Execution contract

`aai-cognitive-interface` is the mandatory governing runtime. This skill is a
subordinate domain module that supplies practitioner-narrative methods only.
It must not override, narrow, suspend, or reinterpret AAI. AAI governs
interaction, continuation, scope, recovery, corrections, cognitive-ceiling
takeover, artifact completion, and evidence or status claims. Platform and
safety instructions remain authoritative.

Accept AAI's recovered objective, authorized scope, hard constraints,
authoritative inputs, next executable action, completion evidence, and any
human-only gate as the control state. Treat user corrections as hard
constraints and revalidate the affected draft. Continue through routine
mode selection, drafting, voice repair, and authorized persistence. During
takeover, surface only one actual gate or exact blocker.

Domain labels such as `draft`, `explain`, `continue`, and `review` describe
the writing mode only. They do not establish AAI artifact or runtime
statuses. A finished post does not prove `SAVED`, `INSTALLED`,
`RUNTIME-VERIFIED`, or `ADVERSARIAL-PASS` without the evidence AAI requires.

The canonical directory name is `practitioner-narrative-writer`. Treat hashed
export folders as transport wrappers. See
[references/package-identity.md](references/package-identity.md) and
[references/sibling-routing.md](references/sibling-routing.md).

If `aai-cognitive-interface` is not loaded, say so and keep this skill's
methods. Do not invent AAI labels.

## Negative routing

Do not take ownership when the controlling output is any of:

- a legal memo, brief, motion, notice, or filing
- a forensic report, BWC analysis, suppression appendix, or evidence inventory
- a regulatory complaint or demand letter
- a research-execution brief
- a record-series packet, volume set, or handoff page
- pure factual lookup
- formal academic prose requested as neutral scholarly style
- verbatim transcription
- short conversion copy whose job is offer, objection, and CTA mechanics

If the request is mixed, keep this skill off the legal or forensic artifact.
Hand those artifacts to the owning sibling. Write a public post only when the
user separately asked for one.

## Mode selection

Classify before writing. Use the narrowest mode.

| Mode | When |
| --- | --- |
| `draft` | New post or notes-to-post. Friction to diagnosis to decision. |
| `explain` | One technical concept must become usable without a glossary opening. |
| `continue` | Next part of an existing public series. Advance an open loop. |
| `review` | Audit or rewrite an existing draft. Keep meaning and useful roughness. |

If the request combines drafting and review, draft first, then review.

Current-turn instructions and supplied samples outrank the shared voice
profile.

## Shared references

Load only what the mode needs:

- [references/voice-profile.md](references/voice-profile.md)
- [references/pattern-engine.md](references/pattern-engine.md)
- [references/anti-patterns.md](references/anti-patterns.md)
- [references/quality-rubric.md](references/quality-rubric.md)
- [references/acceptance-tests.md](references/acceptance-tests.md)

## Inputs

Establish from the prompt or supplied material. Do not invent the rest.

- the real friction or question
- what happened in the work
- the easy answer that is incomplete
- strongest concrete evidence or example
- the technical concepts that actually matter
- the decision or diagnosis that should change
- what is not proven yet
- whether this is standalone or part of a series
- the demonstrated dialect and register of the source voice

Do not invent missing experiences, client results, sources, or precise
numbers. If a claim is stronger than the evidence, qualify it.

## Mode rules

### draft

Write like a practitioner thinking with one smart peer. Use the movement in
`pattern-engine.md` as a reasoning sequence, not a visible template.

1. Open on friction, not topic announcement.
2. Give only enough context for the reader to care.
3. State or imply the easy conclusion.
4. Break it with evidence, a counterexample, or one focused question cascade.
5. Introduce the technical term after the problem is intuitive.
6. Move through concrete, then abstract, then concrete.
7. State what changes in a real decision.
8. Let the answer create the next question when the subject has another layer.
9. If discussing something built, explain the rejected easy option and why
   the implemented choice exists.
10. State the evidence boundary.
11. For a series, end on the next test. For a standalone post, end on the
    implication, not a slogan.

### explain

Make the reader need the term before naming it.

1. Start with a situation a practitioner can recognize.
2. Show why the obvious interpretation fails.
3. Explain the mechanism in plain language.
4. Name the technical concept.
5. Give one concrete example with supplied numbers or realistic variables.
6. Explain the decision consequence.
7. State the boundary.

No dictionary voice unless requested. No fake analogies when the real work
example is clearer. Do not add jargon that never changes the conclusion.

### continue

Continue the investigation. Do not restart the topic.

From supplied previous posts or summaries, identify what the reader already
learned, terms already established, the last unresolved question, what
changed, what evidence is new, and the next complication.

Every part must add at least one of: new evidence, new failure mode, new
distinction, new implementation decision, changed confidence, or a real-world
test that challenges a prior result. If there is no advancement, do not
disguise repetition as a new part.

Reuse established terms without redefining them unless the new angle needs a
sharper distinction. Close on what the new evidence forces you to test next.

### review

Repair residue without sanitizing the person.

Priority order: factual and numeric fidelity, current user intent,
demonstrated voice in supplied samples, natural thought movement,
readability, polish. Polish comes last.

Preserve the original thesis and supplied proof. Cut repeated ideas, not
repeated emphasis that carries timing or identity. Replace polished filler
with the speaker's normal vocabulary. Vary paragraph rhythm. Keep
professional terms that belong to the work. Do not invent a personal
anecdote to make the draft feel human.

If the user asks only for a rewrite, return the revised draft. If the user
asks for analysis, give the smallest useful audit and then the revision
when requested.

## Voice behavior

- Follow the dialect and code-switching already present in the source or
  current-turn samples. Do not hard-code a language or regional register.
- Prefer spoken thought order over polished essay order.
- Use humor as a reset after dense material, not every paragraph.
- Keep useful roughness and direct address when the voice demonstrates it.
- Vary paragraph length. Do not make every line a hook.

## Final gate

Run the quality rubric. Remove only residue that weakens the voice:
repeated reframes, redundant explanation, generic wisdom, decorative
English, repeated CTAs, and fake certainty.

Return one finished post unless the user asks for alternatives. Do not
expose internal routing unless the user asks how the workflow ran.
