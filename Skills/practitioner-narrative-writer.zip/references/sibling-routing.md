# Sibling Routing

AAI stays in force. This skill supplies practitioner-narrative methods only.

| Module | When to load | If missing |
| --- | --- | --- |
| aai-cognitive-interface | Every turn | Stop and say the governor is absent. Do not invent AAI status labels. |
| personal-context | User points at a prior post or series | Structured retrieval gate. Do not reconstruct a definite prior post. |
| research-execution-briefs | The post needs live source gathering first | Gather sources in that skill. Return here only to write the public post. |
| claim-source-auditor | The post restates contested facts from a packet | Keep each claim at the lowest supported type. |
| forensic-evidentiary-drafting | The controlling output is an evidentiary draft | Do not rewrite it as a social post. |
| regulatory-complaint-drafting | The controlling output is a complaint or demand | Do not take ownership. |
| record-series-builder | The controlling output is a volume packet | Do not treat series continuity as record packaging. |
| authority-currency-auditor | The post cites a statute, rule, or regulation as current | Verify against live sources before leaving the claim unqualified. |

Named connectors in SKILL.md are routes, not authorities. Use only tools actually exposed.
